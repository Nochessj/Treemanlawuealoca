<?php

function  conectarDB() {
// datos para la conexion
$servername = "127.0.0.1:3306";
$username = "root";
$password = "";
$dbname = "la chacra";


// crea la conexion
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
  die("Connection failed: " . mysqli_connect_error());
}

echo 'ok';
return $conn;
}

//guarda la consulta para insertar en la base de datos

conectarDB();


if (isset($_POST['enviar'])) {
    // collect value of input field
    $nombre = $_POST['nombre'];
    $apellido = $_POST['apellido'];
    $pass = $_POST['pass'];
    $tele = $_POST['tele'];
    $opcion = $_POST['pets'];
    if (empty($nombre)) {
        echo "Name is empty";
    } else {
        echo  "NOMBRE:".$nombre;
        echo  "APELLIDO:".$apellido;
        echo  "PASS:".$pass;  
        echo  "OPCION:".$opcion;   
        echo  "TELEFONO:".$tele;
        
        $sql = "INSERT INTO Usuario VALUES ('', $pass, '".$nombre."', '".$apellido."',$tele, $opcion);";
    
      $conn = conectarDB();

if (mysqli_query($conn, $sql)) {
  echo "New record created successfully";
} else {
  echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}

mysqli_close($conn);
    }
}


?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form action="" method="post">

    <input type="text" name="nombre" placeholder="Nombre">
    <input type="text" name="apellido" placeholder="Apellido">
        <input type="number" name="pass" placeholder="pass">
        <input type="number" name="tele" placeholder="telefono">
       <select name="pets" id="pet-select">
  <option value="">--Opciones</option>
  <option value="1">A</option>
  <option value="2">M</option>
  <option value="3">C</option>
</select>
    <input type="submit"  name='enviar' value="Enviar">
    </form>

</body>
</html>
<!-- C:\xampp\htdocs\Proyecto La Chacra-ORIGINAL-\Conexion.php -->