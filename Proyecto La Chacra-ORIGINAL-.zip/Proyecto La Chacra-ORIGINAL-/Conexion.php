<?php
function  conectarDB() {
// datos para la conexion
$servername = "127.0.0.1:3306";
$username = "root";
$password = "";
$dbname = "la chacra";


// crea la conexion
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
  die("Connection failed: " . mysqli_connect_error());
}

//echo 'ok';
return $conn;
}

//guarda la consulta para insertar en la base de datos

conectarDB();
?>