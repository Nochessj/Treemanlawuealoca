<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width,initial-scale=1" />
  <title>Dashboard - La Chacra</title>
  <link rel="stylesheet" href="index.css">
  <style>
    .dash{max-width:900px;margin:40px auto;padding:20px;background:rgba(255,255,255,0.95);border-radius:12px;box-shadow:0 8px 24px rgba(0,0,0,0.06)}
    a.btn-logout{display:inline-block;margin-top:12px;padding:8px 14px;background:#c0392b;color:#fff;border-radius:8px;text-decoration:none}
  </style>
</head>
<body>
  <main class="dash">
    <h1>Hola, <?php echo htmlspecialchars($_SESSION['usuario']); ?> 👋</h1>
    <p>Este es tu panel privado. Desde aquí podrás gestionar tu perfil, reservas y más (según funcionalidades futuras).</p>
    <a class="btn-logout" href="logout.php">Cerrar sesión</a>
  </main>
</body>
</html>
