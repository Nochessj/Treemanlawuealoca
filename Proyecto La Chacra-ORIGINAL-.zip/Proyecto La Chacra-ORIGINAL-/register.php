<?php
// register.php - muestra formulario y procesa registro
require_once 'Conexion.php';
require_once 'auth.php'; // reemplaza require_once 'Conexion.php';

$errors = [];
$success = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $usuario = trim($_POST['usuario'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $password2 = $_POST['password2'] ?? '';
    $telefono = trim($_POST['telefono'] ?? '');

    if ($usuario === '' || $email === '' || $password === '') {
        $errors[] = 'Completa todos los campos obligatorios.';
    }
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = 'El correo no tiene un formato válido.';
    }
    if ($password !== $password2) {
        $errors[] = 'Las contraseñas no coinciden.';
    }
    if (empty($errors)) {
        // Verificar si el email ya existe
        $stmt = $conn->prepare('SELECT id FROM usuarios WHERE email = ?');
        $stmt->bind_param('s', $email);
        $stmt->execute();
        $stmt->store_result();
        if ($stmt->num_rows > 0) {
            $errors[] = 'El email ya está registrado.';
            $stmt->close();
        } else {
            $stmt->close();
            $hash = password_hash($password, PASSWORD_DEFAULT);
            $rol = 2; // 1 = admin, 2 = usuario (por defecto)
            $stmt2 = $conn->prepare('INSERT INTO usuarios (usuario, email, password, telefono, rol) VALUES (?, ?, ?, ?, ?)');
            $stmt2->bind_param('ssssi', $usuario, $email, $hash, $telefono, $rol);
            if ($stmt2->execute()) {
                $success = true;
                header('Location: login.php?registered=1');
                exit();
            } else {
                $errors[] = 'Error al registrar: ' . $stmt2->error;
            }
            $stmt2->close();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width,initial-scale=1" />
  <title>Registrarse - La Chacra</title>
  <link rel="stylesheet" href="index.css">
  <style>
    /* Pequeños ajustes al formulario para integrarlo con el diseño existente */
    .auth-container{max-width:420px;margin:40px auto;padding:24px;background:rgba(255,255,255,0.95);border-radius:12px;box-shadow:0 8px 24px rgba(0,0,0,0.08);}
    .auth-container h2{margin-bottom:12px}
    .auth-container input, .auth-container select{width:100%;padding:10px;margin:8px 0;border:1px solid #ddd;border-radius:8px}
    .btn{display:inline-block;padding:10px 18px;border-radius:10px;border:none;cursor:pointer}
    .btn-primary{background:#2b7a5e;color:#fff}
    .errors{color:#b00020;margin-bottom:12px}
    .success{color:#006600;margin-bottom:12px}
  </style>
</head>
<body>
  <main class="auth-container" role="main">
    <h2>Crear cuenta</h2>

    <?php if (!empty($errors)): ?>
      <div class="errors">
        <?php foreach ($errors as $e) echo '<div>'.htmlspecialchars($e).'</div>'; ?>
      </div>
    <?php endif; ?>

    <form method="post" action="register.php" novalidate>
      <label>Nombre de usuario (visible)</label>
      <input type="text" name="usuario" required value="<?php echo htmlspecialchars($_POST['usuario'] ?? '') ?>">

      <label>Correo electrónico</label>
      <input type="email" name="email" required value="<?php echo htmlspecialchars($_POST['email'] ?? '') ?>">

      <label>Contraseña</label>
      <input type="password" name="password" required>

      <label>Repetir contraseña</label>
      <input type="password" name="password2" required>

      <label>Teléfono (opcional)</label>
      <input type="text" name="telefono" value="<?php echo htmlspecialchars($_POST['telefono'] ?? '') ?>">

      <div style="margin-top:12px">
        <button class="btn btn-primary" type="submit">Registrarme</button>
        <a href="login.php" style="margin-left:12px">Ya tengo cuenta</a>
      </div>
    </form>
  </main>
</body>
</html>
