<?php
// admin_panel.php
session_start();

require_once 'auth.php';
require_admin();

// ya tienes $conn disponible desde auth.php ($conn = conectarDB();)
$_SESSION['usuario'] = $_SESSION['usuario'] ?? '';
// Conectar DB (si necesitas datos en esta página)
// $conn ya está definido

// Obtener métricas rápidas
$usersCount = 0;
$productsCount = 0;
$res = mysqli_query($conn, "SELECT COUNT(*) as c FROM usuarios");
if ($r = mysqli_fetch_assoc($res)) $usersCount = $r['c'];

$_SESSION['usuario'] = 2;
include 'Conexion.php';

// Verificar que el usuario sea admin (suponiendo rol=1 es admin)
// if (!isset($_SESSION['usuario']) || $_SESSION['rol'] != 1) {
//     header('Location: login.php');
//     //exit;
// }

// Conectar DB (si necesitas datos en esta página)
$conn = conectarDB();

// Obtener métricas rápidas
$usersCount = 0;
$productsCount = 0;
$res = mysqli_query($conn, "SELECT COUNT(*) as c FROM Usuario");
if ($r = mysqli_fetch_assoc($res)) $usersCount = $r['c'];
//$res = mysqli_query($conn, "SELECT COUNT(*) as c FROM products");
//if ($r = mysqli_fetch_assoc($res)) $productsCount = $r['c'];

?>

<!doctype html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>Admin - La Chacra</title>
  <style>
    /* Reset simple */
    *{box-sizing:border-box;margin:0;padding:0}
    html,body{height:100%;font-family:Inter,system-ui,-apple-system,'Segoe UI',Roboto,'Helvetica Neue',Arial}
    a{color:inherit;text-decoration:none}

    /* Layout */
    .app{display:flex;height:100vh;overflow:hidden}
    .sidebar{width:280px;background:linear-gradient(180deg,#0f172a,#0b1220);color:#fff;padding:28px 18px;display:flex;flex-direction:column;gap:18px}
    .brand{font-weight:700;font-size:20px;letter-spacing:0.6px}
    .menu{margin-top:6px}
    .menu a{display:flex;align-items:center;gap:10px;padding:10px;border-radius:8px;color:#e6eef8;transition:background .2s,transform .08s}
    .menu a:hover{background:rgba(255,255,255,0.04);transform:translateX(6px)}
    .menu a.active{background:linear-gradient(90deg,#1f6feb,#7dd3fc);color:#021427}

    .main{flex:1;background:#f4f7fb;padding:24px;overflow:auto}
    .topbar{display:flex;justify-content:space-between;align-items:center;margin-bottom:18px}
    .search{display:flex;gap:8px;align-items:center}
    .search input{padding:10px 12px;border-radius:10px;border:1px solid #e4e7ec;background:white;width:280px}

    /* Cards */
    .grid{display:grid;grid-template-columns:repeat(3,1fr);gap:16px;margin-bottom:18px}
    .card{background:white;padding:18px;border-radius:12px;box-shadow:0 6px 18px rgba(16,24,40,0.06);transition:transform .18s}
    .card:hover{transform:translateY(-6px)}
    .card h3{font-size:14px;color:#6b7280;margin-bottom:10px}
    .card .value{font-size:28px;font-weight:700}

    /* Table */
    .table-wrap{background:white;border-radius:12px;padding:12px;box-shadow:0 8px 20px rgba(2,6,23,0.06)}
    table{width:100%;border-collapse:collapse}
    th,td{padding:12px;text-align:left;border-bottom:1px solid #eef2f7}
    th{font-size:13px;color:#6b7280}
    tr:hover td{background:linear-gradient(90deg,rgba(99,102,241,0.02),transparent)}

    /* Buttons */
    .btn{display:inline-flex;align-items:center;gap:8px;padding:8px 12px;border-radius:8px;border:none;cursor:pointer}
    .btn.primary{background:#1f6feb;color:white}
    .btn.ghost{background:transparent;border:1px solid #e6eef8}
    .btn.danger{background:#ef4444;color:white}

    /* Modal */
    .modal-backdrop{position:fixed;inset:0;background:rgba(2,6,23,0.4);display:none;align-items:center;justify-content:center}
    .modal{width:760px;background:white;border-radius:12px;padding:18px;transform:translateY(20px);opacity:0;transition:all .18s}
    .modal.show{transform:translateY(0);opacity:1}

    /* Small responsive */
    @media (max-width:900px){.grid{grid-template-columns:repeat(1,1fr)} .sidebar{display:none}.app{flex-direction:column}}

    /* subtle animation keyframes */
    @keyframes blink {0%{opacity:.2}50%{opacity:1}100%{opacity:.2}}
    .live-dot{width:10px;height:10px;background:#22c55e;border-radius:999px;display:inline-block;animation:blink 1.6s infinite}

    /* toast */
    .toast{position:fixed;right:18px;bottom:18px;background:#0b1220;color:white;padding:12px 16px;border-radius:10px;box-shadow:0 6px 18px rgba(2,6,23,0.3);display:none}

  </style>
</head>
<body>

<div class="app">
  <aside class="sidebar" aria-label="Sidebar">
    <div class="brand">La Chacra — Admin</div>
    <div style="font-size:13px;color:#9aa7b6">Usuario: <?php echo htmlspecialchars($_SESSION['usuario']); ?></div>
    <nav class="menu">
      <a href="#dashboard" class="active" data-section="dashboard">📊 Dashboard</a>
      <a href="#usuarios" data-section="usuarios">👥 Usuarios</a>
      <a href="#productos" data-section="productos">🍽 Productos</a>
      <a href="#reportes" data-section="reportes">📈 Reportes</a>
      <a href="#config" data-section="config">⚙️ Configuración</a>
      <a href="../logout.php" style="margin-top:12px;color:#fecaca">Cerrar sesión</a>
    </nav>
    <div style="margin-top:auto;font-size:12px;color:#9aa7b6">Último acceso: <span style="display:inline-block;margin-left:6px" class="live-dot"></span></div>
  </aside>

  <main class="main">
    <div class="topbar">
      <div class="search">
        <input id="globalSearch" placeholder="Buscar usuarios, productos..." />
        <button class="btn ghost" id="openNewBtn">➕ Crear</button>
      </div>
      <div style="display:flex;gap:12px;align-items:center">
        <div style="text-align:right">
          <div style="font-size:12px;color:#6b7280">Panel</div>
          <div style="font-weight:700">Administrador</div>
        </div>
      </div>
    </div>

    <!-- Dashboard -->
    <section id="dashboardSection">
      <div class="grid">
        <div class="card">
          <h3>Usuarios</h3>
          <div class="value" id="usersCount"><?php echo $usersCount; ?></div>
          <div style="font-size:12px;color:#9aa7b6;margin-top:8px">Total registrados</div>
        </div>

        <div class="card">
          <h3>Productos</h3>
          <div class="value" id="productsCount"><?php echo $productsCount; ?></div>
          <div style="font-size:12px;color:#9aa7b6;margin-top:8px">Items en catálogo</div>
        </div>

        <div class="card">
          <h3>Acciones recientes</h3>
          <div style="font-size:13px;color:#374151;margin-top:8px">Última acción: <strong id="lastAction">—</strong></div>
        </div>
      </div>

      <div class="table-wrap">
        <h3 style="margin-bottom:12px">Usuarios recientes</h3>
        <table id="usersTable">
          <thead>
            <tr><th>ID</th><th>Nombre</th><th>Email</th><th>Teléfono</th><th>Rol</th><th>Acciones</th></tr>
          </thead>
          <tbody>
            <!-- Cargado por JS -->
          </tbody>
        </table>
      </div>
    </section>

    <!-- Usuarios -->
    <section id="usuariosSection" style="display:none">
      <h2>Gestión de Usuarios</h2>
      <div class="table-wrap" style="margin-top:12px">
        <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:10px">
          <div>Listado completo</div>
          <div>
            <button class="btn primary" id="btnNewUser">Nuevo usuario</button>
          </div>
        </div>
        <table id="usersTableFull">
          <thead><tr><th>ID</th><th>Nombre</th><th>Apellido</th><th>Email</th><th>Tel</th><th>Rol</th><th>Acciones</th></tr></thead>
          <tbody></tbody>
        </table>
      </div>
    </section>

    <!-- Productos -->
    <section id="productosSection" style="display:none">
      <h2>Gestión de Productos</h2>
      <div style="margin-top:12px">
        <button class="btn primary" id="btnNewProduct">Nuevo producto</button>
      </div>
      <div class="table-wrap" style="margin-top:12px">
        <table id="productsTable"><thead><tr><th>ID</th><th>Nombre</th><th>Precio</th><th>Stock</th><th>Acciones</th></tr></thead><tbody></tbody></table>
      </div>
    </section>

    <!-- Reportes -->
    <section id="reportesSection" style="display:none">
      <h2>Reportes</h2>
      <div class="card" style="margin-top:12px">Aquí puedes agregar gráficas y exportar CSV/PDF.</div>
    </section>

    <!-- Configuración -->
    <section id="configSection" style="display:none">
      <h2>Configuración</h2>
      <div class="card" style="margin-top:12px">Opciones del sitio, backup, etc.</div>
    </section>

  </main>
</div>

<!-- Modal (crear/editar) -->
<div class="modal-backdrop" id="modalBackdrop">
  <div class="modal" id="modal">
    <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:8px">
      <h3 id="modalTitle">Crear</h3>
      <button id="closeModal" class="btn ghost">✖</button>
    </div>

    <form id="modalForm">
      <input type="hidden" name="id" id="modalId">
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px">
        <input name="nombre" id="modalNombre" placeholder="Nombre" required style="padding:10px;border:1px solid #e6eef8;border-radius:8px">
        <input name="apellido" id="modalApellido" placeholder="Apellido" style="padding:10px;border:1px solid #e6eef8;border-radius:8px">
      </div>
      <div style="margin-top:8px;display:flex;gap:8px">
        <input name="telefono" id="modalTelefono" placeholder="Teléfono" style="flex:1;padding:10px;border:1px solid #e6eef8;border-radius:8px">
        <select name="rol" id="modalRol" style="padding:10px;border:1px solid #e6eef8;border-radius:8px">
          <option value="2">Usuario</option>
          <option value="1">Admin</option>
        </select>
      </div>
      <div style="margin-top:10px;text-align:right">
        <button type="submit" class="btn primary">Guardar</button>
      </div>
    </form>
  </div>
</div>

<div class="toast" id="toast">Guardado correctamente</div>

<script>
// --- Manejo de secciones del panel ---
const sections = {
  dashboard: document.getElementById('dashboardSection'),
  usuarios: document.getElementById('usuariosSection'),
  productos: document.getElementById('productosSection'),
  reportes: document.getElementById('reportesSection'),
  config: document.getElementById('configSection')
};

document.querySelectorAll('.menu a').forEach(a=>{
  a.addEventListener('click',(e)=>{
    e.preventDefault();
    document.querySelectorAll('.menu a').forEach(x=>x.classList.remove('active'));
    a.classList.add('active');
    const s = a.dataset.section;
    Object.keys(sections).forEach(k=>sections[k].style.display = (k===s)?'block':'none');
    window.scrollTo({top:0,behavior:'smooth'});
  });
});

// --- Modal ---
const modalBackdrop = document.getElementById('modalBackdrop');
const modal = document.getElementById('modal');
const openNewBtn = document.getElementById('openNewBtn');
const closeModal = document.getElementById('closeModal');
const modalForm = document.getElementById('modalForm');

openNewBtn.addEventListener('click', ()=> openModal('Crear usuario'));
closeModal.addEventListener('click', closeModalFn);
modalBackdrop.addEventListener('click', (e)=>{ if(e.target===modalBackdrop) closeModalFn(); });

function openModal(title){
  document.getElementById('modalTitle').innerText = title;
  modalBackdrop.style.display = 'flex';
  setTimeout(()=> modal.classList.add('show'), 10);
}
function closeModalFn(){ modal.classList.remove('show'); setTimeout(()=> modalBackdrop.style.display='none',180); }

// --- Toast util ---
function toast(msg){
  const t = document.getElementById('toast');
  t.innerText = msg; t.style.display='block';
  setTimeout(()=> t.style.display='none',2200);
}

// --- Fetch datos iniciales y render tabla usuarios/products ---
async function fetchUsers() {
  // Llamar a endpoint PHP que devuelva JSON de usuarios: /admin/api_users.php
  try{
    const res = await fetch('api_users.php');
    const data = await res.json();
    renderUsersTable(data.slice(0,6));
    renderUsersFullTable(data);
  }catch(e){ console.error(e);} 
}

function renderUsersTable(users){
  const tbody = document.querySelector('#usersTable tbody'); tbody.innerHTML='';
  users.forEach(u=>{
    const tr = document.createElement('tr');
    tr.innerHTML = `<td>${u.id}</td><td>${u.nombre}</td><td>${u.email||'-'}</td><td>${u.telefono||'-'}</td><td>${u.rol==1?'Admin':'Usuario'}</td><td><button class="btn ghost" onclick="editUser(${u.id})">Editar</button></td>`;
    tbody.appendChild(tr);
  });
}

function renderUsersFullTable(users){
  const tbody = document.querySelector('#usersTableFull tbody'); tbody.innerHTML='';
  users.forEach(u=>{
    const tr = document.createElement('tr');
    tr.innerHTML = `<td>${u.id}</td><td>${u.nombre}</td><td>${u.apellido||''}</td><td>${u.email||''}</td><td>${u.telefono||''}</td><td>${u.rol==1?'Admin':'Usuario'}</td><td><button class="btn" onclick="editUser(${u.id})">✏️</button> <button class="btn danger" onclick="deleteUser(${u.id})">🗑️</button></td>`;
    tbody.appendChild(tr);
  });
}

// --- Productos ---
async function fetchProducts(){
  try{
    const res = await fetch('api_products.php');
    const data = await res.json();
    const tbody = document.querySelector('#productsTable tbody'); tbody.innerHTML='';
    data.forEach(p=>{
      const tr = document.createElement('tr');
      tr.innerHTML = `<td>${p.id}</td><td>${p.name}</td><td>$${p.price}</td><td>${p.stock}</td><td><button class="btn" onclick="editProduct(${p.id})">✏️</button> <button class="btn danger" onclick="deleteProduct(${p.id})">🗑️</button></td>`;
      tbody.appendChild(tr);
    });
  }catch(e){console.error(e)}
}

// --- Edit / Delete handlers (abrir modal y precargar) ---
window.editUser = async function(id){
  // Pedir datos a api
  const res = await fetch('api_users.php?id='+id);
  const u = await res.json();
  document.getElementById('modalId').value = u.id;
  document.getElementById('modalNombre').value = u.nombre || '';
  document.getElementById('modalApellido').value = u.apellido || '';
  document.getElementById('modalTelefono').value = u.telefono || '';
  document.getElementById('modalRol').value = u.rol || 2;
  openModal('Editar usuario');
}

window.deleteUser = async function(id){
  if(!confirm('Eliminar usuario #'+id+' ?')) return;
  const res = await fetch('api_users.php?id='+id, { method: 'DELETE' });
  const r = await res.json();
  if(r.ok) { toast('Usuario eliminado'); fetchUsers(); }
}

// Productos placeholders
window.editProduct = async function(id){ toast('Abrir editar producto: '+id); }
window.deleteProduct = async function(id){ if(!confirm('Eliminar producto #'+id+' ?')) return; toast('Producto eliminado'); }

// Modal submit -> crear/editar usuario via api
modalForm.addEventListener('submit', async (e)=>{
  e.preventDefault();
  const form = new FormData(modalForm);
  const id = form.get('id');
  const payload = {};
  form.forEach((v,k)=>payload[k]=v);
  try{
    const method = id? 'PUT' : 'POST';
    const url = id ? ('api_users.php?id='+id) : 'api_users.php';
    const res = await fetch(url, { method, headers:{'Content-Type':'application/json'}, body: JSON.stringify(payload)});
    const json = await res.json();
    if(json.ok){ toast('Guardado'); closeModalFn(); fetchUsers(); }
    else toast('Error: '+(json.error||'')); 
  }catch(err){console.error(err);toast('Error de red');}
});

// Buscar global
document.getElementById('globalSearch').addEventListener('input', function(e){
  const q = e.target.value.toLowerCase();
  document.querySelectorAll('#usersTableFull tbody tr').forEach(tr=>{
    tr.style.display = tr.innerText.toLowerCase().includes(q)?'table-row':'none';
  });
});

// Inicializar datos
fetchUsers(); fetchProducts();

</script>

</body>
</html>
