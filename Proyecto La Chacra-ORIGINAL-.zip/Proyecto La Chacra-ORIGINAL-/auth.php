<?php

// auth.php - helpers de autenticación y DB 
if (session_status() === PHP_SESSION_NONE) session_start();

require_once 'Conexion.php';
$conn = conectarDB();

// Helpers
function is_logged_in() {
    return isset($_SESSION['user_id']);
}
function is_admin() {
    return isset($_SESSION['rol']) && intval($_SESSION['rol']) === 1;
}
function require_login() {
    if (!is_logged_in()) {
        header('Location: login.php');
        exit();
    }
}
function require_admin() {
    if (!is_logged_in() || !is_admin()) {
        header('Location: login.php');
        exit();
    }
}
function login_set($id, $usuario, $rol) {
    // Guarda lo mínimo en sesión
    $_SESSION['user_id'] = $id;
    $_SESSION['usuario'] = $usuario;
    $_SESSION['rol'] = intval($rol);
}
function logout_user() {
    $_SESSION = [];
    if (session_status() !== PHP_SESSION_NONE) {
        session_destroy();
    }
}
?>