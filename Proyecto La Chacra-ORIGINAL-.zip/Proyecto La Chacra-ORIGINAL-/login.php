<?php
// login.php - formulario y autenticación
session_start();
require_once 'Conexion.php';

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';

    if ($email === '' || $password === '') {
        $error = 'Completa los datos.';
    } else {
        $stmt = $conn->prepare('SELECT id, usuario, password FROM usuario  = ? LIMIT 1');
        $stmt->bind_param('s', $email);
        $stmt->execute();
        $stmt->store_result();
        if ($stmt->num_rows === 1) {
            $stmt->bind_result($id, $usuario, $hash);
            $stmt->fetch();
            if (password_verify($password, $hash)) {
                // Login OK
                $_SESSION['user_id'] = $id;
                $_SESSION['usuario'] = $usuario;
                header('Location: dashboard.php');
                $_SESSION['usuario'] = 2;

                exit();
            } else {
                $error = 'Contraseña incorrecta.';
            }
        } else {
            $error = 'No existe una cuenta con ese correo.';
        }
        $stmt->close();
    }
}
$registered = isset($_GET['registered']) ? true : false;
?>

<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width,initial-scale=1" />
  <title>Iniciar sesión - La Chacra</title>
  <link rel="stylesheet" href="index.css">
  <style>
    .auth-container{max-width:420px;margin:40px auto;padding:24px;background:rgba(255,255,255,0.95);border-radius:12px;box-shadow:0 8px 24px rgba(0,0,0,0.08);}
    .auth-container input{width:100%;padding:10px;margin:8px 0;border:1px solid #ddd;border-radius:8px}
    .btn{display:inline-block;padding:10px 18px;border-radius:10px;border:none;cursor:pointer}
    .btn-primary{background:#2b7a5e;color:#fff}
    .error{color:#b00020;margin-bottom:12px}
    .success{color:#006600;margin-bottom:12px}
  </style>
</head>
<body>
  <main class="auth-container" role="main">
    <h2>Iniciar sesión</h2>
    <?php if ($registered): ?>
      <div class="success">Registro exitoso. Ya podés iniciar sesión.</div>
    <?php endif; ?>
    <?php if ($error): ?>
      <div class="error"><?php echo htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <form method="post" action="login.php" novalidate>
      <label>Correo electrónico</label>
      <input type="email" name="email" required value="<?php echo htmlspecialchars($_POST['email'] ?? '') ?>">

      <label>Contraseña</label>
      <input type="password" name="password" required>

      <div style="margin-top:12px">
        <button class="btn btn-primary" type="submit">Entrar</button>
        <a href="register.php" style="margin-left:12px">Crear cuenta</a>
      </div>
    </form>
  </main>
</body>
</html>
