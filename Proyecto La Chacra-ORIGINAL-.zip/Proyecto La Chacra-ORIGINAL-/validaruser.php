<?php
require 'Conexion.php';

//llamando a la funcion conectarDB
$llamada= conectarDB();
/* validar el login del usuario*/
if(!empty($_POST['user']) && !empty($_POST['pass'])){
    try {
        //code...
        $user=$_POST['user'];
        $pass=$_POST['pass'];
    
        $query="SELECT id FROM usuario WHERE email='$user' AND  Contraseña='$pass'";
    
    
        $result=mysqli_query($llamada, $query);
    
        $row=mysqli_num_rows($result);
        if($row >0){
            //guardar en la variable los datos en un vector
            $rowlist = mysqli_fetch_array($result);

           echo    "existe usuario";
           

           // echo '<script language="javascript">alert("Starting...");</script>';
            
           //abrir session para guardar el id del usuario, es decir del perfil. 
           //session_start();
          // $_SESSION['id']=$rowlist["Persona_idPersona"];
        
           //redireccionamiento de Pagina principal.
         //  header("Location: /web2021/menu/main.php");
           /*echo '<script language="javascript">window.location.replace("/Web2021/Menu/principal.html?userid=<?php echo $row[0];?>");</script>';*/
           

    
        }else{
            echo "No se ha encontrado un registro.";
    
        }
    } catch (\Throwable $th) {
        //throw $th;
        echo "error.";
    }
    
    mysqli_free_result($result);
    mysqli_close($con);
    
    

    
 }
?>