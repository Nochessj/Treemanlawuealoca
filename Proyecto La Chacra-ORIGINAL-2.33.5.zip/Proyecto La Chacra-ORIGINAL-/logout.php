<?php
session_start();

// Vacía todas las variables de sesión
$_SESSION = [];

// Destruye la sesión completamente
session_destroy();

// Redirige al inicio del sitio
header("Location: index.html");
exit;
?>
