<?php
require_once 'Conexion.php';
$conn = conectarDB();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nombre = trim($_POST['nombre']);
    $apellido = trim($_POST['apellido']);
    $telefono = trim($_POST['telefono']);
    $email = trim($_POST['email']);
    $password = trim($_POST['password']);

    // Validación básica
    if (!empty($nombre) && !empty($apellido) && !empty($email) && !empty($password)) {
        
        // Verificar si el email ya existe
        $check_email = "SELECT ID_U FROM usuario WHERE email = '$email'";
        $result = mysqli_query($conn, $check_email);
        
        if (mysqli_num_rows($result) > 0) {
            echo "<script>alert('El correo electrónico ya está registrado.');</script>";
        } else {
            // Encriptar contraseña (más seguro que texto plano)
            $hashed = password_hash($password, PASSWORD_DEFAULT);

            // ID_Tipo 3 = Cliente
            $sql = "INSERT INTO usuario (contraseña, nombre, apellido, telefono, email, ID_Tipo) 
                    VALUES ('$hashed', '$nombre', '$apellido', '$telefono', '$email', 3)";
            
            if (mysqli_query($conn, $sql)) {
                echo "<script>alert('Registro exitoso. Ahora puedes iniciar sesión.'); window.location='login.php';</script>";
            } else {
                echo "Error: " . mysqli_error($conn);
            }
        }
    } else {
        echo "<script>alert('Por favor, completa todos los campos obligatorios.');</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<title>Registro - La Chacra Gourmet</title>
<link rel="stylesheet" href="auth.css">
</head>
<body>
<div class="auth-container">
    <h2>Registro de Usuario</h2>
    <form method="POST" action="">
        <input type="text" name="nombre" placeholder="Nombre" required>
        <input type="text" name="apellido" placeholder="Apellido" required>
        <input type="email" name="email" placeholder="Correo Electrónico" required>
        <input type="text" name="telefono" placeholder="Teléfono">
        <input type="password" name="password" placeholder="Contraseña" required>
        <button type="submit">Registrarse</button>
        <p>¿Ya tienes cuenta? <a href="login.php">Inicia sesión</a></p>
    </form>
</div>
</body>
</html>
