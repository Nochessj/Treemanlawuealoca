<?php
session_start();
require_once 'Conexion.php';
$conn = conectarDB();

// Control de acceso
if (!isset($_SESSION['id']) || !isset($_SESSION['tipo']) || intval($_SESSION['tipo']) !== 1) {
    header("Location: login.php");
    exit;
}

$seccion = $_GET['seccion'] ?? 'dashboard';

// === USUARIOS ===
if ($seccion === 'usuarios' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['borrar'])) {
        $id = intval($_POST['id']);
        mysqli_query($conn, "DELETE FROM usuario WHERE ID_U = $id");
    } elseif (isset($_POST['cambiar_tipo'])) {
        $id = intval($_POST['id']);
        $tipo = intval($_POST['tipo']);
        mysqli_query($conn, "UPDATE usuario SET ID_Tipo = $tipo WHERE ID_U = $id");
    }
    header("Location: PanelAdministrador.php?seccion=usuarios");
    exit;
}

// === STOCK ===
if ($seccion === 'stock' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['agregar'])) {
        $nombre = mysqli_real_escape_string($conn, $_POST['nombre']);
        $tipo = mysqli_real_escape_string($conn, $_POST['tipo']);
        $cantidad = intval($_POST['cantidad']);
        $fecha = $_POST['fecha'] ?: date('Y-m-d');
        mysqli_query($conn, "INSERT INTO stock (nombre, tipo, cantidad_disponible, fecha_actualizacion)
                             VALUES ('$nombre', '$tipo', $cantidad, '$fecha')");
    } elseif (isset($_POST['borrar'])) {
        $id = intval($_POST['id']);
        mysqli_query($conn, "DELETE FROM stock WHERE ID_Stock = $id");
    } elseif (isset($_POST['editar'])) {
        $id = intval($_POST['id']);
        $nombre = mysqli_real_escape_string($conn, $_POST['nombre']);
        $tipo = mysqli_real_escape_string($conn, $_POST['tipo']);
        $cantidad = intval($_POST['cantidad']);
        $fecha = $_POST['fecha'] ?: date('Y-m-d');
        mysqli_query($conn, "UPDATE stock 
                             SET nombre='$nombre', tipo='$tipo', cantidad_disponible=$cantidad, fecha_actualizacion='$fecha' 
                             WHERE ID_Stock=$id");
    }
    header("Location: PanelAdministrador.php?seccion=stock");
    exit;
}

// === RESERVAS ===
if ($seccion === 'reservas' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['borrar'])) {
        $id = intval($_POST['id']);
        mysqli_query($conn, "DELETE FROM reserva WHERE ID_Reserva = $id");
    }
    header("Location: PanelAdministrador.php?seccion=reservas");
    exit;
}

// === CONSULTAS ===
$usuarios = mysqli_query($conn, "SELECT * FROM usuario ORDER BY ID_U DESC");
$stock = mysqli_query($conn, "SELECT * FROM stock ORDER BY ID_Stock DESC");
$reservas = mysqli_query($conn, "SELECT * FROM reserva ORDER BY fecha DESC, hora DESC");

// === ESTADÍSTICAS ===
$contUsuarios = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS c FROM usuario"))['c'];
$contStock = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS c FROM stock"))['c'];
$contReservas = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS c FROM reserva"))['c'];
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<title>Panel Administrador - La Chacra Gourmet</title>
<style>
:root {
  --fondo: linear-gradient(135deg, #0b0b0b, #1a1a3d);
  --panel: #1f1f2e;
  --verde: #3ac569;
  --claro: #e8f0e8;
  --texto: #f9fafb;
  --rojo: #d9534f;
  --azul: #5bc0de;
  --amarillo: #f0ad4e;
}
body {
  background: var(--fondo);
  color: var(--texto);
  font-family: 'Poppins', sans-serif;
  margin: 0;
  padding: 0;
}
header {
  background: var(--panel);
  padding: 15px 40px;
  display: flex;
  justify-content: space-between;
  align-items: center;
  box-shadow: 0 2px 10px rgba(0,0,0,0.3);
}
header h1 {
  margin: 0;
  font-size: 22px;
  letter-spacing: 1px;
}
nav a {
  text-decoration: none;
  color: var(--claro);
  margin-left: 15px;
  padding: 8px 14px;
  border-radius: 8px;
  transition: 0.3s;
}
nav a:hover {
  background: var(--verde);
  color: #111;
}
nav .activo {
  background: var(--verde);
  color: #111;
}
main {
  padding: 30px 40px;
}
.cards {
  display: flex;
  flex-wrap: wrap;
  gap: 20px;
}
.card {
  background: var(--panel);
  border-radius: 12px;
  padding: 25px;
  width: 250px;
  text-align: center;
  box-shadow: 0 6px 20px rgba(0,0,0,0.35);
  transition: transform 0.3s;
}
.card:hover { transform: translateY(-5px); }
.card h3 { margin-top: 0; }
.card p {
  font-size: 28px;
  color: var(--verde);
  margin: 10px 0;
}
table {
  width: 100%;
  border-collapse: collapse;
  margin-top: 20px;
  background: rgba(255,255,255,0.02);
  border-radius: 10px;
  overflow: hidden;
}
th, td {
  padding: 10px 12px;
  border-bottom: 1px solid rgba(255,255,255,0.08);
}
th {
  background: rgba(255,255,255,0.05);
  text-align: left;
}
input, select {
  background: #151522;
  border: 1px solid rgba(255,255,255,0.15);
  color: var(--texto);
  padding: 6px;
  border-radius: 6px;
}
button {
  background: var(--verde);
  color: #111;
  border: none;
  padding: 6px 10px;
  border-radius: 6px;
  cursor: pointer;
  transition: 0.2s;
}
button:hover { opacity: 0.85; }
.danger {
  background: var(--rojo);
  color: #fff;
}
footer {
  text-align: center;
  padding: 20px;
  border-top: 1px solid rgba(255,255,255,0.1);
  background: var(--panel);
  margin-top: 40px;
}
</style>
</head>
<body>
<header>
  <h1>Panel Administrador — La Chacra Gourmet</h1>
  <nav>
    <a href="?seccion=dashboard" class="<?= $seccion==='dashboard'?'activo':'' ?>">Dashboard</a>
    <a href="?seccion=usuarios" class="<?= $seccion==='usuarios'?'activo':'' ?>">Usuarios</a>
    <a href="?seccion=stock" class="<?= $seccion==='stock'?'activo':'' ?>">Stock</a>
    <a href="?seccion=reservas" class="<?= $seccion==='reservas'?'activo':'' ?>">Reservas</a>
    <a href="logout.php" style="color:var(--rojo);font-weight:bold;">Salir</a>
  </nav>
</header>

<main>
<?php if ($seccion === 'dashboard'): ?>
  <h2>Resumen general</h2>
  <div class="cards">
    <div class="card"><h3>Usuarios</h3><p><?= $contUsuarios ?></p></div>
    <div class="card"><h3>Stock</h3><p><?= $contStock ?></p></div>
    <div class="card"><h3>Reservas</h3><p><?= $contReservas ?></p></div>
  </div>

<?php elseif ($seccion === 'usuarios'): ?>
  <h2>Gestión de Usuarios</h2>
  <table>
    <thead><tr><th>Nombre</th><th>Apellido</th><th>Teléfono</th><th>Tipo</th><th>Acciones</th></tr></thead>
    <tbody>
    <?php while ($u = mysqli_fetch_assoc($usuarios)): ?>
      <tr>
        <td><?= htmlspecialchars($u['nombre']) ?></td>
        <td><?= htmlspecialchars($u['apellido']) ?></td>
        <td><?= htmlspecialchars($u['telefono']) ?></td>
        <td>
          <form method="POST">
            <input type="hidden" name="id" value="<?= $u['ID_U'] ?>">
            <select name="tipo" onchange="this.form.submit()">
              <option value="1" <?= $u['ID_Tipo']==1?'selected':'' ?>>👑 Admin</option>
              <option value="2" <?= $u['ID_Tipo']==2?'selected':'' ?>>🧑‍🍳 Mozo</option>
              <option value="3" <?= $u['ID_Tipo']==3?'selected':'' ?>>👤 Cliente</option>
            </select>
            <input type="hidden" name="cambiar_tipo" value="1">
          </form>
        </td>
        <td>
          <form method="POST" onsubmit="return confirm('¿Eliminar usuario?')">
            <input type="hidden" name="id" value="<?= $u['ID_U'] ?>">
            <button name="borrar" class="danger">Eliminar</button>
          </form>
        </td>
      </tr>
    <?php endwhile; ?>
    </tbody>
  </table>

<?php elseif ($seccion === 'stock'): ?>
  <h2>Gestión de Stock</h2>
  <form method="POST" style="margin-bottom:15px;">
    <input type="text" name="nombre" placeholder="Nombre del producto" required>
    <select name="tipo" required>
      <option value="">Tipo...</option>
      <option value="🍽 Alimento">🍽 Alimento</option>
      <option value="🍹 Bebida">🍹 Bebida</option>
      <option value="🧂 Ingrediente">🧂 Ingrediente</option>
    </select>
    <input type="number" name="cantidad" placeholder="Cantidad" required>
    <input type="date" name="fecha">
    <button name="agregar">Agregar</button>
  </form>

  <table>
    <thead><tr><th>Nombre</th><th>Tipo</th><th>Cantidad</th><th>Fecha</th><th>Acciones</th></tr></thead>
    <tbody>
    <?php while ($s = mysqli_fetch_assoc($stock)): ?>
      <tr>
        <form method="POST">
          <input type="hidden" name="id" value="<?= $s['ID_Stock'] ?>">
          <td><input type="text" name="nombre" value="<?= htmlspecialchars($s['nombre']) ?>" required></td>
          <td>
            <select name="tipo">
              <option value="🍽 Alimento" <?= $s['tipo']=='🍽 Alimento'?'selected':'' ?>>🍽 Alimento</option>
              <option value="🍹 Bebida" <?= $s['tipo']=='🍹 Bebida'?'selected':'' ?>>🍹 Bebida</option>
              <option value="🧂 Ingrediente" <?= $s['tipo']=='🧂 Ingrediente'?'selected':'' ?>>🧂 Ingrediente</option>
            </select>
          </td>
          <td><input type="number" name="cantidad" value="<?= $s['cantidad_disponible'] ?>" required></td>
          <td><input type="date" name="fecha" value="<?= $s['fecha_actualizacion'] ?>"></td>
          <td>
            <button name="editar">💾</button>
            <button name="borrar" class="danger" onclick="return confirm('¿Eliminar producto?')">🗑</button>
          </td>
        </form>
      </tr>
    <?php endwhile; ?>
    </tbody>
  </table>

<?php elseif ($seccion === 'reservas'): ?>
  <h2>Gestión de Reservas</h2>
  <table>
    <thead><tr><th>N° Mesa</th><th>Fecha</th><th>Hora</th><th>Acciones</th></tr></thead>
    <tbody>
    <?php while ($r = mysqli_fetch_assoc($reservas)): ?>
      <tr>
        <td><?= ($r['num_mesa'] ?? rand(1,6)) ?></td>
        <td><?= htmlspecialchars($r['fecha']) ?></td>
        <td><?= htmlspecialchars($r['hora']) ?></td>
        <td>
          <form method="POST" onsubmit="return confirm('¿Eliminar reserva?')">
            <input type="hidden" name="id" value="<?= $r['ID_Reserva'] ?>">
            <button name="borrar" class="danger">Eliminar</button>
          </form>
        </td>
      </tr>
    <?php endwhile; ?>
    </tbody>
  </table>
<?php endif; ?>
</main>

<footer>© 2025 La Chacra Gourmet — Panel de Administración</footer>
</body>
</html>

