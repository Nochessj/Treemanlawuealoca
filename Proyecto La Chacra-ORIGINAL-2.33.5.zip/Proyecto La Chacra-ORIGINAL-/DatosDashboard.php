<?php
require_once 'Conexion.php';
$conn = conectarDB();

// Obtener datos desde las tablas
$usuarios = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS total FROM usuario"))['total'] ?? 0;
$stock = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS total FROM stock"))['total'] ?? 0;
$reservas = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS total FROM reserva"))['total'] ?? 0;

// Enviar como JSON
header('Content-Type: application/json');
echo json_encode([
    'usuarios' => intval($usuarios),
    'stock' => intval($stock),
    'reservas' => intval($reservas)
]);
?>
