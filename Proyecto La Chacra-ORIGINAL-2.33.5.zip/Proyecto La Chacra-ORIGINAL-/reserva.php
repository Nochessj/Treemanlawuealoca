<?php
require_once 'Conexion.php';
$conn = conectarDB();

header('Content-Type: application/json; charset=utf-8');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nombre = mysqli_real_escape_string($conn, $_POST['nombre']);
    $fecha = mysqli_real_escape_string($conn, $_POST['fecha']);
    $hora = mysqli_real_escape_string($conn, $_POST['hora']);
    $personas = intval($_POST['personas']);

    $sql = "INSERT INTO reserva (nombre_cliente, fecha, hora, personas)
            VALUES ('$nombre', '$fecha', '$hora', $personas)";
    $ok = mysqli_query($conn, $sql);

    if ($ok) {
        echo json_encode(['ok' => true, 'mensaje' => '✅ Reserva enviada correctamente.']);
    } else {
        echo json_encode(['ok' => false, 'mensaje' => '❌ Error al enviar la reserva.']);
    }
    exit;
}
?>
