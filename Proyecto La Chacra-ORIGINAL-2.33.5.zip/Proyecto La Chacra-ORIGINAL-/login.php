<?php
require_once 'Conexion.php';
session_start();
$conn = conectarDB();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email']);
    $password = trim($_POST['password']);

    $sql = "SELECT * FROM usuario WHERE email = '$email'";
    $result = mysqli_query($conn, $sql);

    if ($result && mysqli_num_rows($result) === 1) {
        $user = mysqli_fetch_assoc($result);
        if (password_verify($password, $user['contraseña'])) {
            $_SESSION['usuario'] = $user['nombre'];
            $_SESSION['id'] = $user['ID_U'];
            $_SESSION['tipo'] = $user['ID_Tipo'];
            $_SESSION['email'] = $user['email'];

            echo "<script>alert('Bienvenido, ".$user['nombre']."'); window.location='index.html';</script>";
        } else {
            echo "<script>alert('Contraseña incorrecta');</script>";
        }
    } else {
        echo "<script>alert('Correo electrónico no encontrado');</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<title>Iniciar Sesión - La Chacra Gourmet</title>
<link rel="stylesheet" href="auth.css">
</head>
<body>
<div class="auth-container">
    <h2>Iniciar Sesión</h2>
    <form method="POST" action="">
        <input type="email" name="email" placeholder="Correo Electrónico" required>
        <input type="password" name="password" placeholder="Contraseña" required>
        <button type="submit">Entrar</button>
        <p>¿No tienes cuenta? <a href="register.php">Regístrate</a></p>
    </form>
</div>
</body>
</html>