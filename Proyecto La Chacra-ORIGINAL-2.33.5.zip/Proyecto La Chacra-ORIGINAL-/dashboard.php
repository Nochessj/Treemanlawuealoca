<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width,initial-scale=1" />
  <title>Dashboard - La Chacra</title>
  <link rel="stylesheet" href="index.css">
  <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
  <style>
    body {
      background: #f5f6fa;
      font-family: "Poppins", sans-serif;
      color: #222;
      margin: 0;
      padding: 0;
    }
    .dash {
      max-width: 1100px;
      margin: 50px auto;
      padding: 30px;
      background: white;
      border-radius: 16px;
      box-shadow: 0 10px 25px rgba(0,0,0,0.1);
    }
    h1 {font-size: 1.8rem; color: #2c3e50; margin-bottom: 10px;}
    p {color: #555;}
    a.btn-logout {
      display: inline-block;
      margin-top: 15px;
      padding: 10px 18px;
      background: #c0392b;
      color: #fff;
      border-radius: 8px;
      text-decoration: none;
      transition: background .2s;
    }
    a.btn-logout:hover {background: #a93226;}

    .cards {
      display: flex;
      gap: 20px;
      flex-wrap: wrap;
      justify-content: space-around;
      margin: 30px 0;
    }
    .card {
      flex: 1;
      min-width: 200px;
      background: #ecf0f1;
      border-radius: 10px;
      text-align: center;
      padding: 20px;
      box-shadow: 0 2px 6px rgba(0,0,0,0.05);
    }
    .card h3 {margin: 0; color: #34495e;}
    .card p {
      font-size: 1.6rem;
      font-weight: bold;
      color: #27ae60;
      margin: 10px 0 0;
    }

    .charts {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
      gap: 25px;
      margin-top: 40px;
    }
    canvas {
      background: #fafafa;
      border-radius: 10px;
      padding: 10px;
      box-shadow: 0 2px 8px rgba(0,0,0,0.06);
    }
  </style>
</head>

<body>
  <main class="dash">
    <h1>Hola, <?php echo htmlspecialchars($_SESSION['usuario']); ?> 👋</h1>
    <p>Bienvenido a tu panel de control. Aquí puedes visualizar la actividad general del sistema en tiempo real.</p>
    <a class="btn-logout" href="logout.php">Cerrar sesión</a>

    <section class="cards">
      <div class="card">
        <h3>Usuarios</h3>
        <p id="usuariosCount">0</p>
      </div>
      <div class="card">
        <h3>Stock</h3>
        <p id="stockCount">0</p>
      </div>
      <div class="card">
        <h3>Reservas</h3>
        <p id="reservasCount">0</p>
      </div>
    </section>

    <section class="charts">
      <canvas id="chartUsuarios"></canvas>
      <canvas id="chartStock"></canvas>
      <canvas id="chartReservas"></canvas>
    </section>
  </main>

  <script>
  const charts = {
    usuarios: new Chart(document.getElementById('chartUsuarios'), {
      type: 'doughnut',
      data: {
        labels: ['Usuarios activos'],
        datasets: [{
          data: [0],
          backgroundColor: ['#27ae60']
        }]
      },
      options: { plugins: { title: { display: true, text: 'Usuarios activos' } } }
    }),
    stock: new Chart(document.getElementById('chartStock'), {
      type: 'bar',
      data: {
        labels: ['Stock disponible'],
        datasets: [{
          data: [0],
          backgroundColor: ['#2980b9']
        }]
      },
      options: { plugins: { title: { display: true, text: 'Stock actual' } } }
    }),
    reservas: new Chart(document.getElementById('chartReservas'), {
      type: 'pie',
      data: {
        labels: ['Reservas'],
        datasets: [{
          data: [0],
          backgroundColor: ['#f39c12']
        }]
      },
      options: { plugins: { title: { display: true, text: 'Reservas en curso' } } }
    })
  };

  async function actualizarDatos() {
    const resp = await fetch('datosDashboard.php');
    const data = await resp.json();

    // Actualizar contadores
    document.getElementById('usuariosCount').textContent = data.usuarios;
    document.getElementById('stockCount').textContent = data.stock;
    document.getElementById('reservasCount').textContent = data.reservas;

    // Actualizar gráficos
    charts.usuarios.data.datasets[0].data = [data.usuarios];
    charts.stock.data.datasets[0].data = [data.stock];
    charts.reservas.data.datasets[0].data = [data.reservas];

    charts.usuarios.update();
    charts.stock.update();
    charts.reservas.update();
  }

  actualizarDatos();
  setInterval(actualizarDatos, 5000);
  </script>
</body>
</html>

